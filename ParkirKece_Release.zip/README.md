# Parkir Kece
Build APK otomatis via GitHub Actions (tanpa Android Studio).

## Cara Pakai
1) Buat repo GitHub dan upload semua file project ini.
2) Buka tab **Actions** → jalankan workflow **Build APK**.
3) Setelah selesai, unduh **Artifacts → ParkirKece-APK**.

Login:
- admin / 12345
- petugas / 0000